﻿using DataLayer.DataContext;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuisnessLayer.Manager
{
    public static class DatabaseConfigurationManager
    {
        public static void ApplyMigration()

        {
            CareQDataContext dataContext = new();

            if (dataContext.Database.GetPendingMigrations().Any())
            {
                dataContext.Database.Migrate();
            }
        }

        public static void InitConnectionString(string connectionString)
        {
            CareQDataContext.ConnectionString = connectionString;
        }
    }
}