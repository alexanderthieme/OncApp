﻿using BuisnessLayer.Models.API.Request;
using BuisnessLayer.Models.API.Response;
using DataLayer.DataManager;
using DataLayer.Models.DataModels;
using Microsoft.EntityFrameworkCore;

namespace BuisnessLayer.DataServices
{
    public class PatienteService : BaseDataService
    {
        public PatienteService(DataManager dataManager)
           : base(dataManager)
        {

        }

        public async Task<ServiceResponse<bool>> CreatePatient(CreatePatientModel model)
        {
            ServiceResponse<bool> response = new();
            response.Message = "Flase";
            bool isPatientExist = await DataManager.GetNoTracking<CareQ_Patient>(x => x.UID.Equals(model.UID)).AnyAsync();

            if(!isPatientExist)
            {
                CareQ_Patient patient = new()
                {
                    UID = model.UID,
                    Date = DateTime.Now,
                    Email = model.Email,
                    PhoneNumber = model.PhoneNumber,
                    WeightBeforeTreatment = model.WeightBeforeTreatment,
                };  
                await DataManager.AddAsync(patient);
                await DataManager.SaveChangesAsync();
                response.Message = "True";
                return response;
            }
            return response;
        }

    }
}
