﻿using BuisnessLayer.Models;
using BuisnessLayer.Models.API.Response;
using DataLayer.DataManager;
using DataLayer.Models.DataModels;
using Microsoft.EntityFrameworkCore;

namespace BuisnessLayer.DataServices
{
    public class AccountService : BaseDataService
    {
        public AccountService(DataManager dataManager)
            : base(dataManager)
        {
        }
        public async Task<ServiceResponse<LoginResponseModel>> Login(LoginRequestModel userModel)
        {

            CareQ_Doctor? doctor = await DataManager.GetNoTracking<CareQ_Doctor>(x => x.Email.ToLower().Equals(userModel.Email.ToLower()) && x.Password.ToLower() == userModel.Password.ToLower()).FirstOrDefaultAsync();
            ServiceResponse<LoginResponseModel>? response = new ServiceResponse<LoginResponseModel>();
            response.Data = new();
            if (doctor is null)
            {
                response.Message = ("Check Credentials");
            }
            else
            {
                response.Data.Name = doctor.Name;
                response.Data.SurName = doctor.SurName;
                response.Data.Email = doctor.Email;
                response.Message = ("There you go");

            }
            return response;//model;
        }
    }
}
