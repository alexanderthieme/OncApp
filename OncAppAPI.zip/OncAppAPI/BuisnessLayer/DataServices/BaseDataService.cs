﻿using DataLayer.DataManager;

namespace BuisnessLayer.DataServices
{
    public class BaseDataService
    {
        protected DataManager DataManager;

        public BaseDataService(DataManager dataManager)
        {
            DataManager = dataManager;
        }
    }
}
