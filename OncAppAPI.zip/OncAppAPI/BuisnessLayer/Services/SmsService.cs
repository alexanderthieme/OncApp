﻿using BuisnessLayer.Models.API.Response;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace BuisnessLayer.Services
{
    public class SmsService : ISmsService
    {
        public async Task<ServiceResponse<bool>> SendSmsAsync(string PhoneNumber)
        {
            //some exception handling
            ServiceResponse<bool> serviceResponse = new ServiceResponse<bool>();
            string accountSid = "AC5bb56241aafb5f38780fa34e450e7e33";
            string authToken = "35b39e46e5ee52aa5b718340095bf648";
            TwilioClient.Init(accountSid, authToken);

            CreateMessageOptions messageOptions = new CreateMessageOptions(
                new Twilio.Types.PhoneNumber("+36" + PhoneNumber))
            {
                From = new Twilio.Types.PhoneNumber("+18589433902"),
                Body = "  "
            };

            MessageResource message = await MessageResource.CreateAsync(messageOptions);
            if (true)//add condition later
            {
                serviceResponse.Data = true;
                serviceResponse.Message = "Message Sent";
            }
            return serviceResponse;
            //Console.WriteLine(message.Body);
        }

        public async Task<ServiceResponse<bool>> SendSmsAsync(SmsRequestModel smsRequestModel)
        {
            ServiceResponse<bool> serviceResponse = new ServiceResponse<bool>();
            if (smsRequestModel.Hash == "ec6f3c9a-c3a8-47c6-b4ce-c31e9304afd0")
            {
                string accountSid = "ACf652854a9f0348d5906cfa0833cdb0e8";
                string authToken = "71357f0338d3b0cbb3654701f37c89f5";
                TwilioClient.Init(accountSid, authToken);

                CreateMessageOptions messageOptions = new CreateMessageOptions(
                    new Twilio.Types.PhoneNumber("+374" + smsRequestModel.PhonNumber))
                {
                    From = new Twilio.Types.PhoneNumber("+14066454366"),
                    Body = smsRequestModel.Body
                };

                MessageResource message = await MessageResource.CreateAsync(messageOptions);

                if (true)//add condition later
                {
                    serviceResponse.Data = true;
                    serviceResponse.Message = "Message Sent";
                }
                return serviceResponse;
            }
            return serviceResponse;
        }
    }
}