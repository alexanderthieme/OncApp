﻿using BuisnessLayer.Models.API.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuisnessLayer.Services
{
    public interface ISmsService
    {
        public Task<ServiceResponse<bool>> SendSmsAsync(string PhoneNumber);

        public Task<ServiceResponse<bool>> SendSmsAsync(SmsRequestModel smsRequestModel);
    }
}