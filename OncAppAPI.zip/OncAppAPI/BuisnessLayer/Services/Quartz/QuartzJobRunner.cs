﻿using Quartz;

namespace BuisnessLayer.Services.Quartz
{
    [DisallowConcurrentExecution]
    public class QuartzJobRunner : IJob
    {
        private readonly IServiceProvider _serviceProvider;

        public QuartzJobRunner(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public async Task Execute(IJobExecutionContext context)
        {
            if (context.MergedJobDataMap.Count > 0)
            {
                foreach (KeyValuePair<string, object> jobDataMap in context.MergedJobDataMap)
                {

                }
            }
        }
    }
}