﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuisnessLayer.Services.Quartz.Job
{
    public static class LdapJob
    {
        public static async Task Execute(IServiceProvider serviceProvider)
        {
            using IServiceScope scope = serviceProvider.CreateScope();

          //  ILdapService ldapService = scope.ServiceProvider.GetRequiredService<ILdapService>();
           // IUserManagerBase userManagerBase = scope.ServiceProvider.GetRequiredService<IUserManagerBase>();
          //  ISettingsManagerBase settingManagerBase = scope.ServiceProvider.GetRequiredService<ISettingsManagerBase>();

            //LdapAppSettings ldapAppSettings = settingManagerBase.GetLdapAppSettings();
            //UserTree cheif = ldapService.GetTreeUsers(ldapAppSettings.ChiefDn);

            //await userManagerBase.UpdateLdapUsers(cheif);
        }
    }
}