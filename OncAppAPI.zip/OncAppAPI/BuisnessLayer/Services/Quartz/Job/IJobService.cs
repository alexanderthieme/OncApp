﻿//namespace BuisnessLayer.Services.Quartz.Job
//{
//    public interface IJobService
//    {
//        public Task CreateJobsAsync(List<ScheduleJob> scheduleJobs);

//    }
//}
