﻿namespace BuisnessLayer.Services
{
    public class SmsRequestModel
    {
        public string PhonNumber { get; set; }
        public string Body { get; set; }
        public string Hash { get; set; }
    }
}