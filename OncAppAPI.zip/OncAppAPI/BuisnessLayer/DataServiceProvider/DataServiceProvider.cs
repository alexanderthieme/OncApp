﻿using BuisnessLayer.DataServices;
using DataLayer.DataManager;

namespace BuisnessLayer.DataServiceProvider
{
    public class DataServiceProvider : IDataServiceProvider
    {
        private readonly DataManager dataManager;
        private AccountService accountService;
        private PatienteService patientService;

        public DataServiceProvider()
        {
            if (dataManager is null)
            {
                dataManager = new();
            }
        }
        public AccountService AccountService => accountService ?? (accountService = new(dataManager));
        public PatienteService PatientService => patientService ?? (patientService = new(dataManager));



    }
}
