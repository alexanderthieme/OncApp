﻿using BuisnessLayer.DataServiceProvider;
using BuisnessLayer.Models.API.Request;
using BuisnessLayer.Models.API.Response;
using Microsoft.AspNetCore.Mvc;

namespace OncApp.Controllers
{


    [Route("Api/Patient")]
    [Produces("application/json")]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public class PatientController : ControllerBase
    {
        protected IDataServiceProvider DataServiceProvider;
        private readonly IHttpContextAccessor _contextAccessor;

        private HttpContext Context => _contextAccessor.HttpContext;
        public PatientController(IDataServiceProvider dataServiceProvider, IHttpContextAccessor contextAccessor)
        {
            _contextAccessor = contextAccessor;
            DataServiceProvider = dataServiceProvider;
        }

        [HttpPost]
        //TODO add attributes
        public async Task<ServiceResponse<bool>> SubmitAdminOrder([FromBody] CreatePatientModel model)
        {
            ServiceResponse<bool> responseModel = await DataServiceProvider.PatientService.CreatePatient(model);
            return responseModel;
        }



    }
}
