﻿using BuisnessLayer.DataServiceProvider;
using BuisnessLayer.Models;
using BuisnessLayer.Models.API.Response;
using Microsoft.AspNetCore.Mvc;

namespace OncApp.Controllers
{

    [Route("Api/Login")]
    [Produces("application/json")]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public class UserController : ControllerBase
    {
        protected IDataServiceProvider DataServiceProvider;
        private readonly IHttpContextAccessor _contextAccessor;

        private HttpContext Context => _contextAccessor.HttpContext;
        public UserController(IDataServiceProvider dataServiceProvider, IHttpContextAccessor contextAccessor)
        {
            _contextAccessor = contextAccessor;
            DataServiceProvider = dataServiceProvider;
        }


        /// <summary>
        /// Login and get. Required model "LoginUserModel"
        /// </summary>
        [HttpPost]
        public async Task<ServiceResponse<LoginResponseModel>> Login([FromBody] LoginRequestModel user)
        {
            ServiceResponse<LoginResponseModel>? response = await DataServiceProvider.AccountService.Login(user);
            return response;
        }
    }
}
