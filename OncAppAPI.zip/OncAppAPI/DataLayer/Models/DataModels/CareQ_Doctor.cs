﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models.DataModels
{

    public class CareQ_Doctor
    {
        [Required(AllowEmptyStrings = false), MaxLength(200)]
        public string Name { get; set; }

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required(AllowEmptyStrings = false), MaxLength(200)]
        public string SurName { get; set; }

        [Required(AllowEmptyStrings = false), MaxLength(80)]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(AllowEmptyStrings = false), MaxLength(8)]
        public string Password { get; set; }


    }
}
