﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataLayer.Models.DataModels
{
    public class CareQ_Patient
    {
  
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required(AllowEmptyStrings = false), MaxLength(80)]
        public string UID { get; set; }

        [Required(AllowEmptyStrings = false), MaxLength(80)]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(AllowEmptyStrings = false), MaxLength(80)]//validation
        public string PhoneNumber { get; set; }

        [Required(AllowEmptyStrings = false), MaxLength(80)]//Treatment Date
        public DateTime Date { get; set; }

        public double WeightBeforeTreatment { get; set; }
    }
}
