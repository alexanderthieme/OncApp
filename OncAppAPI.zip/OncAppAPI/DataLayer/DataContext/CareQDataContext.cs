﻿using DataLayer.Models.DataModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DataLayer.DataContext
{
    public class CareQDataContext : DbContext
    {
        #region DataModel
        private DbSet<CareQ_Patient> Patients { get; set; }
        private DbSet<CareQ_Doctor> Doctors{ get; set; }
        #endregion

        public static string ConnectionString { get; set; }

        public CareQDataContext()
        {

        }

        public CareQDataContext(DbContextOptions<CareQDataContext> options) : base(options)
        {
            
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=KESHSISH;Initial Catalog=CareQDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            IMutableKey userPrimaryKey = modelBuilder.Model.FindEntityType(typeof(CareQ_Patient)).FindPrimaryKey();
            base.OnModelCreating(modelBuilder);

        }

        public override int SaveChanges()
        {
            return base.SaveChanges();
        }

        public async Task<int> SaveChangesAsync()
        {
            return await base.SaveChangesAsync();
        }

    }
}