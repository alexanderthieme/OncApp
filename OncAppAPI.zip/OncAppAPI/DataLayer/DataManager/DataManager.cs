﻿using DataLayer.DataContext;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace DataLayer.DataManager
{
    public class DataManager : IDisposable
    {
        private readonly CareQDataContext dbContext;

        public DataManager()
        {
            if (dbContext is null)
            {
                dbContext = new();
            }
        }

        public IQueryable<T> GetNoTracking<T>(Expression<Func<T, bool>> predicate, params string[] includes) where T : class
        {
            IQueryable<T> set = dbContext.Set<T>();

            for (int i = 0; i < includes.Length; i++)
            {
                set = set.Include(includes[i]);
            }

            if (predicate is null)
            {   
                return set.AsNoTracking();
            }
            else
            {
                return set.AsNoTracking().Where(predicate);
            }
        }

        public IQueryable<T> GetNoTracking<T>(params string[] includes) where T : class
        {
            IQueryable<T> set = dbContext.Set<T>();

            for (int i = 0; i < includes.Length; i++)
            {
                set = set.Include(includes[i]);
            }

            return set.AsNoTracking();
        }

        public async Task AddAsync<T>(T entity) where T : class
        {
            dbContext.Set<T>().Add(entity);

           
        }

        public IQueryable<T> Get<T>(Expression<Func<T, bool>> predicate, params string[] includes) where T : class
        {
            IQueryable<T> set = dbContext.Set<T>();

            for (int i = 0; i < includes.Length; i++)
            {
                set = set.Include(includes[i]);
            }

            if (predicate is null)
            {
                return set;
            }
            else
            {
                return set.Where(predicate);
            }
        }

        public async Task UpdateAsync<T>(T entity ) where T : class
        {
            dbContext.Set<T>().Attach(entity);

        
        }

        public async Task<int> SaveChangesAsync( )
        {
 

            return await dbContext.SaveChangesAsync();
        }

        #region Dispose

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (dbContext is not null)
                    {
                        dbContext.Dispose();
                    }
                }
            }

            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        ~DataManager()
        {
            Dispose(false);
        }

        #endregion Dispose

        public async Task DeleteAsync<T>(T entity, bool withSave = false, int? userID = null, bool ignoreSoftDeletable = false) where T : class
        {
          
                dbContext.Set<T>().Remove(entity);
        }
    }
}